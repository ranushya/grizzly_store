<script type="text/javascript">
$(window).load(function()
{	
	$("div.pro_des").hide();
                
});
$(document).ready(function()
{
		$("#view-btn").click(function(){
					$("div.pro_des").show();
                                        $("div.product").hide();
                                                                                                                               

        
                  });
                $("#finish").click(function(){
					$("div.product").show();
					$("div.pro_des").hide();
                                                                                                                               
		  });
                $("#cancel").click(function(){
					$("div.product").show();
					$("div.pro_des").hide();
                                                                                                                               
		  });
});
</script>